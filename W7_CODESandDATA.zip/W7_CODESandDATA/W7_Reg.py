"""
@author: Abolfazl Saghafi
Intro to Data Science 2 - Regression
"""
## Changing working directory
#cd C:\\Users\\asagh_vv0qi6r\\.spyder-py3\\mlcourse

## Loading required packages
import pandas as pd
import matplotlib.pyplot as plt  	# to visualize
import seaborn as sb
#from pandas.plotting import scatter_matrix


## Loading data
########################################
df = pd.read_csv('carmpg.csv', sep=',')
df.info()                           # var info
df["weight"] = df["weight"].astype('float')     # change var type
df["origin"] = df["origin"].astype('category')
df.isnull().sum()                   # missing values
df.dropna()                         # remove cases w missing values


## Exploratory Analysis - Qualitative - Univariate
########################################
# Do for each qual var seperately 
tb = df['origin'].value_counts()
print(tb)
ax = tb.plot.bar(x='Made in', y='Frequency', rot=0)     # bar chart
ax = tb.plot.pie(x='Made in', y='Frequency', rot=0)     # pie chart

tb = df['modelyear'].value_counts()
print(tb)
ax = tb.plot.bar(x='Model Year', y='Frequency', rot=0)


## Exploratory Analysis - Quantitative - Univariate
########################################
# Do for each quant var seperately
df.info()
df.describe()                       # short summary statistics
sb.distplot(df["horsepower"].dropna(), kde=False)
plt.hist(df["horsepower"],bins=6,edgecolor='k')
df.boxplot(column=['horsepower'], return_type='axes')

# Response var is especial
df['mpg'].describe()
sb.distplot(df["mpg"].dropna(), kde=False)      # dist plot
df.boxplot(column=['mpg'], return_type='axes')  # box plot

# Removing outliers
q_1 = df["mpg"].quantile(0.25)
q_3  = df["mpg"].quantile(0.75)
q_low = q_1 - 1.5*(q_3-q_1)
q_hi = q_3 + 1.5*(q_3-q_1)
print(q_low,q_hi)
df = df[(df["mpg"] < q_hi) & (df["mpg"] > q_low)]

sb.distplot(df["mpg"].dropna(), kde=False)      # dist plot
plt.hist(df["mpg"],bins=10,edgecolor='k')       # histogram


## Exploratory Analysis - Bivariate
########################################
# For multiple quant vars
pd.crosstab(index=df['modelyear'], columns=df['origin'])
tb = pd.crosstab(index=df['modelyear'], columns=df['origin'])
ax = tb.plot.barh()

# For qaunt over qual values, especially response over qual
sb.boxplot(x="modelyear", y="mpg", data=df) 
sb.boxplot(x="origin", y="mpg", data=df)

# Seperate scatterplot
plt.scatter(df['displacement'], df['mpg'])
plt.scatter(df['horsepower'], df['mpg'])
plt.scatter(df['weight'], df['mpg'])

# Scatterplot overlay for qual var
sb.pairplot(x_vars=['weight'], y_vars=['mpg'], data=df, hue="origin", size=5)


## Reducing data, working with just numerical variables
########################################
# Do this if you have important quant vars
mpg = df[(df['origin']== 'USA')]
mpg = mpg[['mpg','cylinders','displacement',
           'horsepower','weight','acceleration','modelyear']]
mpg.info()
sb.distplot(mpg["mpg"].dropna(), kde=False)
mpg.corr(method='pearson')
pd.plotting.scatter_matrix(mpg, alpha=0.2)
plt.show()


## Fitting a MLR 
########################################
import statsmodels.api as sm
#from statsmodels.formula.api import ols

mpg.isnull().sum()                   # missing values
mpg = mpg.dropna()                   # removing cases w missing values

# Seperating Predictors and Response
X = mpg[['cylinders','displacement',
           'horsepower','weight','acceleration','modelyear']]
Y = mpg[['mpg']]
X = sm.add_constant(X)               # Adding intercept 
lsfit = sm.OLS(Y,X).fit()            # Fitting regression model
lsfit.summary()                      # GoF measures and summary   

lsfit.mse_resid                      # MSE


# Polishing model, removing insignificant vars
X = mpg[['cylinders','weight','acceleration','modelyear']]
X = sm.add_constant(X)               # Adding intercept 
lsfit = sm.OLS(Y,X).fit()            # Fitting regression model
lsfit.summary()                      # GoF measures and summary  
 
lsfit.mse_resid                      # MSE

# Model prediction for new inputs withing its input range
x = pd.DataFrame([[1, 6, 3380, 15, 78]])
prediction = lsfit.get_prediction(x)
prediction.summary_frame() 
prediction.table


