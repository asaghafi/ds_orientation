"""
@author: Abolfazl Saghafi
Intro to Data Science 2 - Dim Reduction & Clustering
"""
## Changing working directory
#cd C:\\Users\\asagh_vv0qi6r\\.spyder-py3\\mlcourse

## Loading required packages
import pandas as pd
import matplotlib.pyplot as plt     # to visualize
import seaborn as sb                # to visualize


## Loading data
########################################
df = pd.read_csv('credit_cluster.csv', sep=',')
df.info()                           # var info
del df["CUST_ID"]                   # remove ID var
df.isnull().sum()                   # missing values
df = df.dropna()                    # remove cases w missing values


## Exploratory Analysis - Univariate
########################################
# Do for each quant var seperately
df.info()
sum_stat = df.describe()            # short summary statistics

# Univariate Summary and Charts
df['BAL'].describe()
df.boxplot(column=['BAL'], return_type='axes')
sb.distplot(df["BAL"], kde=False)      # dist plot

df['PUR'].describe()
df.boxplot(column=['PUR'], return_type='axes')
sb.distplot(df["PUR"], kde=False)      # dist plot

plt.style.use('seaborn-whitegrid')  # all histograms in one big plot
df.hist(bins=20, figsize=(60,40), color='blue', edgecolor='red')
plt.show()

## Exploratory Analysis - Bivariate
########################################
# Do for each combination of two vars

corr_stat = df.corr()                   # correlation coefficients
print(corr_stat)
sb.heatmap(df.corr());                  # simple Heatmap

# A better heatmap, mixing chart with correlation coefficients
plt.figure(figsize=(16, 6))
heatmap = sb.heatmap(df.corr(), vmin=-1, vmax=1, annot=True);
heatmap.set_title('Correlation Heatmap', fontdict={'fontsize':12}, pad=12);

# 2D Scatterplot with 2 vars
plt.scatter(df['BAL'], df['PUR'])

# Matrix Scatterplot
sb.pairplot(df, diag_kind="kde")

# 3D Scatterplot with 3 vars
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(df['BAL'], df['PUR'], df['PAYMENTS'])
plt.show()


## Dimension Reduction
########################################
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


df_std =  StandardScaler().fit_transform(df)    # standardizing (df-df.mean())/df.std()
cov_matrix = np.cov(df_std.T)                   # covariance matrix
print("cov_matrix shape:",cov_matrix.shape)


# Computing eigenvalues and eigenvectors
eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
# Make a set of (eigenvalue, eigenvector) pairs:
eig_pairs = [(eigenvalues[index], eigenvectors[:,index]) for index in range(len(eigenvalues))]
# Sort the (eigenvalue, eigenvector) pairs from highest to lowest
eig_pairs.sort()
eig_pairs.reverse()
# Extract the descending ordered eigenvalues and eigenvectors
eigvalues_sorted = [eig_pairs[index][0] for index in range(len(eigenvalues))]
eigvectors_sorted = [eig_pairs[index][1] for index in range(len(eigenvalues))]
# Let's confirm our sorting worked, print out eigenvalues
print('Eigenvalues in descending order: \n%s' %eigvalues_sorted)
tot = sum(eigenvalues)
# an array of variance explained by each eigen vector
var_explained = [(i / tot) for i in sorted(eigenvalues, reverse=True)] 
# an array of cumulative variance, reaching almost 100%
cum_var_exp = np.cumsum(var_explained)

# Plotting The Explained Variance by Principal Components
plt.bar(range(1,len(eigenvalues)+1), var_explained, alpha=0.5, align='center', label='individual explained variance')
plt.step(range(1,len(eigenvalues)+1),cum_var_exp, where= 'mid', label='cumulative explained variance')
plt.ylabel('Explained variance ratio')
plt.xlabel('Principal components')
plt.legend(loc = 'best')
plt.show()


# P_reduce represents reduced mathematical space....
dim_num = 7                                   # number of new dimensions
P_reduce = np.array(eigvectors_sorted[0:dim_num])
df_std_7D = np.dot(df_std,P_reduce.T)         # projecting original data to new pace
reduced_pca = pd.DataFrame(df_std_7D)         # converting array to dataframe for pairplot
reduced_pca

# Matrix Scarreplot of transformed observations
sb.pairplot(reduced_pca, diag_kind='kde') 


## Dimension Reduction Application on Images
########################################
from PIL import Image
from numpy import asarray 
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

img = Image.open('doggo.jpg')
img.show()
print(img.size)     # size is 1280*793, it means that number of variables
print(img.mode)     # mode is RGB, means 1280*793*3 values

img = asarray(img)                # image to array transformation
blue,green,red = cv2.split(img)   # splitting the image to R,G,B arrays

pca = PCA(500)                    # initialize PCA with first 500 PCs

red_transformed = pca.fit_transform(red)               # apply PCA to red channel
red_inverted = pca.inverse_transform(red_transformed)  # project to new PCs
green_transformed = pca.fit_transform(green)           # apply PCA to green channel
green_inverted = pca.inverse_transform(green_transformed)
blue_transformed = pca.fit_transform(blue)             # apply PCA to blue channel
blue_inverted = pca.inverse_transform(blue_transformed)

img_compressed = (np.dstack((blue_inverted, green_inverted, red_inverted))).astype(np.uint8)
img_new = Image.fromarray(img_compressed, 'RGB')       # array to image transform
img_new.show()
print(img_new.size)     # size is the same as before
print(img_new.mode)     # RGB as before
img_new.save("doggo_2.jpg")


## Clustering 
########################################
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sb

df_std =  StandardScaler().fit_transform(df)  # standardizing (df-df.mean())/df.std()
df_mms = MinMaxScaler().fit_transform(df)     # standardizing (df-df.min())/(df.max()-df.min())

# Finding optimum number of clusters from 2 to 10
score = []
K = range(2,10)
for k in K:
    km = KMeans(n_clusters=k)
    km = km.fit(df_std)                       # switch to df_mms and see the difference
    score.append(silhouette_score(df_std, km.labels_, metric='euclidean'))

# Plotting Average Silhouette vs number of clusters
plt.plot(K, score, 'bx-')
plt.xlabel('k')
plt.ylabel('average silhouette score')
plt.title('Optimal k')
plt.show()

# Performing K-mean w optimum number of clusters, change the number below
kmeans = KMeans(n_clusters=3)
kmeans.fit(df_std)
y_kmeans = kmeans.predict(df_std)


# 2D Scatterplot with 2 vars, colored for predicted clusters
df_new = pd.DataFrame(df)
df_new[["label"]] = y_kmeans
df_new["label"] = df_new["label"].astype('category')
sb.scatterplot('BAL','PUR', data=df_new, hue='label')


# Reduce dimension to visualize clusters, run lines 75-96 first
dim_num = 3
P_reduce = np.array(eigvectors_sorted[0:dim_num])
df_std_3D = np.dot(df_std,P_reduce.T)  # projecting original data to new space
reduced_pca = pd.DataFrame(df_std_3D)  # converting array to dataframe for pairplot
reduced_pca[["label"]] = y_kmeans
reduced_pca.columns = ['PC1','PC2','PC3','label']

# 3D plot on 3 PCs
fig = plt.figure() 
ax = fig.add_subplot(111, projection='3d')
ax.scatter(reduced_pca['PC1'], reduced_pca['PC2'], reduced_pca['PC3'], 
           c=reduced_pca['label'], cmap="plasma")
ax.view_init(azim=180, elev=10)        # azimuth angle on x,y, elevation angle on z, 
plt.show()


## Clustering Example - Iris Dataset
########################################
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sb

df_orig = pd.read_csv('iris.csv', sep=',')
df_orig.info()  
df = df_orig.loc[:, df_orig.columns != 'Species']

df_std = StandardScaler().fit_transform(df) 

score = []
K = range(2,10)
for k in K:
    km = KMeans(n_clusters=k)
    km = km.fit(df_std)                       # switch to df_mms and see the difference
    score.append(silhouette_score(df_std, km.labels_, metric='euclidean'))

plt.plot(K, score, 'bx-')
plt.xlabel('k')
plt.ylabel('average silhouette score')
plt.title('Optimal k')
plt.show()

# Performing K-mean w optimum number of clusters
kmeans = KMeans(n_clusters=2)
kmeans.fit(df_std)
y_kmeans = kmeans.predict(df_std)

# Run lines 76-96 first, P_reduce represents reduced mathematical space....
dim_num = 2
P_reduce = np.array(eigvectors_sorted[0:dim_num])  # R^4 to R^2 space
df_std_2D = np.dot(df_std,P_reduce.T)         # projecting original data to new pace
reduced_pca = pd.DataFrame(df_std_2D)  # converting array to dataframe for pairplot
reduced_pca[["label"]] = y_kmeans
reduced_pca.columns = ['PC1','PC2','label']

# Scatterplot overlay for predicted labels
sb.scatterplot('PC1','PC2', data=reduced_pca, hue='label')


# Using 3 PCs and adding original labels to plot
dim_num = 3
P_reduce = np.array(eigvectors_sorted[0:dim_num])  # R^4 to R^3 space
df_std_3D = np.dot(df_std,P_reduce.T)         # projecting original data to new pace
reduced_pca = pd.DataFrame(df_std_3D)  # converting array to dataframe for pairplot
reduced_pca[["label"]] = df_orig['Species'].astype('category')
reduced_pca.columns = ['PC1','PC2','PC3','label']
reduced_pca["label"] = reduced_pca["label"].cat.codes

# 3D plot using 3 PCs
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(reduced_pca['PC1'], reduced_pca['PC2'], reduced_pca['PC3'], 
           c=reduced_pca['label'], cmap="plasma")
#ax.view_init(azim=180, elev=10)         # azimuth angle on x,y, elevation angle on z, 
plt.show()

# Original data 
sb.pairplot(df_orig, diag_kind='kde', hue="Species") 



