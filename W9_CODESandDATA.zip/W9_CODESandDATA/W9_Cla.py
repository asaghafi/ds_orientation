"""
@author: Abolfazl Saghafi
Intro to Data Science 2 - Classification
"""
## Changing working directory
#cd C:\\Users\\abolf\\.spyder-py3\\mlcourse

## Loading required packages
import pandas as pd                # to import data
import matplotlib.pyplot as plt    # to visualize
import seaborn as sb               # to visualize


## Loading data
########################################
df = pd.read_csv('iris.csv', sep=',')
df.info()                           # var info
df.isnull().sum()                   # missing values


## Exploratory Analysis - Qualitative - Univariate
########################################
# Do for each qual var seperately 
tb = df['Species'].value_counts()
print(tb)
ax = tb.plot.bar(x='Iris Types', y='Frequency', rot=0)     # bar chart
ax = tb.plot.pie(x='Iris Types', y='Frequency', rot=0)     # pie chart


## Exploratory Analysis - Quantitative - Univariate
########################################
# Do for each quant var seperately
df.describe()                                           # short summary stat

sb.distplot(df["Sepal.Length"], kde=False)              # dist plot
plt.hist(df["Sepal.Length"],bins=6,edgecolor='k')       # histogram
df.boxplot(column=['Sepal.Length'], return_type='axes') # box plot


## Exploratory Analysis - Bivariate
########################################
# Do for each combination of two vars
df.groupby("Species")['Sepal.Length'].describe().reset_index() # summary over Species
tb = df.groupby("Species").describe().reset_index()            # all at once

corr_stat = df.corr()                   # correlation coefficients
print(corr_stat)

# Heatmap with correlation coefficients
plt.figure(figsize=(16, 6))
heatmap = sb.heatmap(df.corr(), vmin=-1, vmax=1, annot=True);
heatmap.set_title('Correlation Heatmap', fontdict={'fontsize':12}, pad=12);
plt.show()

# Matrix Scatterplot, color coded for species
sb.pairplot(df, hue="Species", diag_kind="kde")
plt.show()


## Pre-processing
########################################
from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.preprocessing import StandardScaler

# Seperating Response and Independent Vars, Pick two Independent vars
X = df[['Sepal.Length', 'Sepal.Width']]
y = df['Species']

# Recoding: setosa --> 0, versicolor --> 1, virginica --> 2
y = pd.factorize(y, sort=True)[0]       
species = ['setosa', 'versicolor', 'virginica']

# Train/Test Random Split after shuffling
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=0, shuffle=True)

# Changing to numpy arrays 
X_array = np.asarray(X)
X_train_array = np.asarray(X_train)
X_test_array = np.asarray(X_test)


## Variable normalization
scale = StandardScaler()                  # scaler function
scale.fit(X_train)                        # calculate μ & σ
X_std = scale.transform(X)                # apply the normalization
X_train_std = scale.transform(X_train)
X_test_std = scale.transform(X_test)

# color assignment
y_str = y.astype(np.str)
y_str[y_str == '0'] = 'red'               # setosa 
y_str[y_str == '1'] = 'blue'              # versocolor
y_str[y_str == '2'] = 'green'             # virginica

# label for charts
def add_labels(standardized=False):
    plt.title('Iris Dataset Visualization')
    if standardized:
        plt.xlabel('Sepal Length (standardized)')
        plt.ylabel('Sepal Width (standardized)')
    else:
        plt.xlabel('Sepal Length (cm)')
        plt.ylabel('Sepal Width (cm)')
    plt.tight_layout()
    plt.show()
    
plt.scatter(X['Sepal.Length'], X['Sepal.Width'], c=y_str)
add_labels()


## Building the ANN model and train it
########################################
import numpy as np
from sklearn.neural_network import MLPClassifier
from mlxtend.plotting import plot_decision_regions
from sklearn import metrics

# Initializing the multilayer perceptron
model = MLPClassifier(hidden_layer_sizes=(4,), learning_rate_init=0.01,
                      max_iter=500)

# Option:
#MLPClassifier(activation='relu', alpha=0.0001, batch_size='auto', beta_1=0.9, 
#beta_2=0.999, early_stopping=False, epsilon=1e-08,       
#hidden_layer_sizes=10, learning_rate='constant',      
#learning_rate_init=0.01, max_iter=500, momentum=0.9,       
#nesterovs_momentum=True, power_t=0.5, random_state=None,       
#shuffle=True, solver='sgd', tol=0.0001, validation_fraction=0.1,       
#verbose=False, warm_start=False)

# Training the model using training set data
model.fit(X_train_std, y_train)

# Accuracy of trained model on test set
print("{:.1%} of the test set was correct.".format(
        metrics.accuracy_score(y_test, model.predict(X_test_std))))

## Plotting the decision boundary on all data
plot_decision_regions(X_std, y, clf=model, 
                      X_highlight=X_test_std, 
                      colors='red,blue,green')
add_labels(standardized=True)


## Goodness of Fit Measures
########################################
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_recall_fscore_support as score

# Confusion Matrix
y_pred = model.predict(X_test_std)
pd.crosstab(index=y_pred, columns=y_test)

# Overall Accuracy & F-score
accuracy_score(y_test,y_pred)   
f1_score(y_test, y_pred, average='macro') 

# Measures for Each Category
precision, recall, fscore, support = score(y_test, y_pred)
print('precision: {}'.format(precision))
print('recall: {}'.format(recall))
print('fscore: {}'.format(fscore))
print('support: {}'.format(support))        # actual labels count

